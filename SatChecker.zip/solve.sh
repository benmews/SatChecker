#!/bin/sh

##### Python
echo "Python"
python3 BCP-JW.py $*
