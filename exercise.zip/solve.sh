#!/bin/sh

##### Python
echo "Python"
python3 example.py $*
