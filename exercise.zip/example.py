import sys


#def makefiles(start, stop):
#    files = []
#    for i in range(start, stop+1):
#        files.append("example-"+str(i)+".cnf")
#    return files

def parse_dimacs(filename):
    largest = 0
    smallest = 0
    clauses = []
    with open(sys.argv[1], 'r') as input_file:
        for line in input_file:
            if line[0] in ['c', 'p']:
                continue
            literals = list(map(int, line.split()))
            assert literals[-1] == 0
            literals = literals[:-1]
            if max(literals) > largest:
                largest = max(literals)
            if min(literals) < smallest:
                smallest = min(literals)
                clauses.append(literals)
        if largest < smallest*-1:
            largest = smallest*-1
    return clauses, largest

def delete_doubles(clauses):
    for clause in clauses:
        for var in clause:
            if var*-1 in clause:
                clauses.remove(clause)
                break
    return clauses
    
def hasUnit(clauses, trail, watch):
    watch
    return has, var, val

def hasUnsat():
    return False
    
def BCP(trail, clauses, watch):
    while hasUnit(clauses,trail, watch)[0] == True:
        trail.push(hasUnit(clauses,...)[1:])
    if hasUnsat(clauses, vals):
        return False
    return True

def decide(num_vars, activities, trail):
    if len(trail) >= num_vars:
        return False
    unassigned = activities.copy()
    for trai in trail:
        var = trai[0]
        if var < 0:
            var=var*-1
        unassigned.remove(var-1)
    highest = max(unassigned)
    x = activities.index(highest)
    v = False # negative first
    trail.append(x, v, False)
    return True
    
def backtrack(trail):
    while True:
        if len(trail) == 0:
            return False
        x,v,b = trail[-1]
        del trail[-1]
        if not b:
            trail.append(x, not v, True)
            return True

def createWatch(clauses, num_vars):
    watch = []*(num_vars*2)
    for clause in clauses:
        for var in clause[0:2]:
            if var < 0:
                watch[((var*-1)*2)-1].append(var)
            else:
                watch[(var-1)*2].append(var)
    return watch
    
def DPLL(clauses, num_vars):
    trail = []
    activities = [0] * num_vars
    watch = createWatch(clauses, num_vars)
    if not BCP(clauses, trail, watch):
        return "unsat"
    while True:
        if not decide(trail, num_vars, activities):
            return "sat"
        while not BCP(clauses, trail, watch):
            if not backtrack():
                return "unsat"

def brute():
    return "unsat"

def run(file):
    results = []
    clauses, num_vars = parse_dimacs(file)
    clauses = delete_doubles()
#    results.append(DPLL(clauses, num_vars))
    results.append(brute(clauses, num_vars))
    return results


results = run(sys.argv[1]) 
#clauses = run("example-1.cnf")

#results = run(makefiles(1,100))
print("unsat")
sys.exit(20)
