#!/bin/sh

##### Python
echo "Python"
python3 2var-JW.py $*
